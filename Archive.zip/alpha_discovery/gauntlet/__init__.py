# alpha_discovery/gauntlet/__init__.py
from .run import run_gauntlet

__all__ = ["run_gauntlet"]
