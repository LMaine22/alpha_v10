# alpha_discovery/data/loader.py

import os
import sys
import pandas as pd

# Support both "python -m alpha_discovery.data.loader" and direct script execution
try:
    from ..config import settings  # Preferred: relative import when run as a package module
except Exception:
    # Fallback for direct script execution (no package context)
    PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    if PROJECT_ROOT not in sys.path:
        sys.path.insert(0, PROJECT_ROOT)
    from alpha_discovery.config import settings

# The 5th row in Excel is index 4 for programming (0-indexed)
HEADER_ROW = 4

# Resolve project root (repo root) regardless of invocation CWD
REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))


def _resolve_path(path: str) -> str:
    """Resolve a possibly-relative path.
    - If absolute: return as-is.
    - If relative: try CWD/path, then REPO_ROOT/path. Return first existing.
    - If none exist: default to REPO_ROOT/path absolute so parent dirs are stable for output paths.
    """
    if os.path.isabs(path):
        return path
    # Candidate 1: relative to current working directory
    cand1 = os.path.abspath(os.path.join(os.getcwd(), path))
    if os.path.exists(cand1):
        return cand1
    # Candidate 2: relative to repository root
    cand2 = os.path.abspath(os.path.join(REPO_ROOT, path))
    if os.path.exists(cand2):
        return cand2
    # Default to REPO_ROOT joined path (useful for output paths that may not exist yet)
    return cand2


def convert_excel_to_parquet():
    """
    Loads data from the source Excel file, combines all sheets,
    and saves the result to a more efficient Parquet file.

    This is a one-time operation.
    """
    excel_cfg = settings.data.excel_file_path
    parquet_cfg = settings.data.parquet_file_path

    excel_path = _resolve_path(excel_cfg)
    parquet_path = _resolve_path(parquet_cfg)

    if not os.path.exists(excel_path):
        # Provide both configured and resolved paths to aid debugging
        print(f" Error: Excel file not found. Configured='{excel_cfg}' | Resolved='{excel_path}'")
        print(" Tip: Ensure the Excel file exists relative to the repo root or provide an absolute path in settings.data.excel_file_path.")
        return

    print(f" Loading Excel file from '{excel_path}'...")
    try:
        xls = pd.ExcelFile(excel_path)

        all_dfs = []
        for sheet_name in xls.sheet_names:
            # Read the sheet, assuming the header is at the specified row
            df = pd.read_excel(xls, sheet_name=sheet_name, header=HEADER_ROW)

            # Standardize the date column name
            if 'Dates' in df.columns:
                df = df.rename(columns={'Dates': 'Date'})

            if 'Date' not in df.columns:
                print(f" Warning: Sheet '{sheet_name}' is missing the 'Date' column. Skipping.")
                continue

            # Drop rows where the Date is missing
            df.dropna(subset=['Date'], inplace=True)

            # Make 'Date' the index
            df['Date'] = pd.to_datetime(df['Date'])
            df = df.set_index('Date')

            # Prepend the sheet name (ticker) to each column
            df = df.add_prefix(f"{sheet_name}_")
            all_dfs.append(df)

        print("Combining data from all sheets...")
        # Combine all dataframes, aligning by the 'Date' index
        combined_df = pd.concat(all_dfs, axis=1, join='outer')

        # Sort by date and forward-fill missing values
        combined_df = combined_df.sort_index()
        combined_df.ffill(inplace=True)

        # Ensure the output directory exists
        os.makedirs(os.path.dirname(parquet_path), exist_ok=True)

        print(f" Saving combined data to Parquet file at '{parquet_path}'...")
        combined_df.to_parquet(parquet_path)
        print(f" Conversion successful! Shape of saved data: {combined_df.shape}")

    except Exception as e:
        print(f" An error occurred during conversion: {e}")


def load_data_from_parquet() -> pd.DataFrame:
    """
    Loads the processed data from the Parquet file.
    This should be used for all subsequent data loading in the project.
    """
    parquet_path = settings.data.parquet_file_path

    if not os.path.exists(parquet_path):
        print(f" Parquet file not found at '{parquet_path}'.")
        print("Please run the conversion from Excel first.")
        return pd.DataFrame()

    print(f"Loading data from '{parquet_path}'...")
    df = pd.read_parquet(parquet_path)
    print(f"Data loaded successfully. Shape: {df.shape}")
    return df


if __name__ == '__main__':
    # This allows you to run the script directly from your terminal
    # to perform the one-time data conversion.
    # Example command: python -m alpha_discovery.data.loader
    convert_excel_to_parquet()